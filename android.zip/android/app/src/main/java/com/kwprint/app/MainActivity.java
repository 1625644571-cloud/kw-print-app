package com.kwprint.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
